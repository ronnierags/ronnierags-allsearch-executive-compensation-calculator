# AllSearch Executive Compensation Calculator — source export

This archive contains the current web calculator, API server, shared libraries, workspace configuration, and source assets. It excludes installed dependencies, build output, screenshots, local settings, and secrets.

## For Claude
Upload this ZIP and describe the change you want. The calculator UI and compensation formulas have been approved; preserve them unless explicitly asked to change them. The web app lives in `artifacts/executive-comp-calculator`; the email/PDF endpoint is in `artifacts/api-server/src/routes/leads.ts`. Shared API contracts and database code live in `lib/`.

## Current email status
The PDF flow and lead submission have been updated to report email failures clearly. Outbound email still requires verification of the sender domain (`allsearchinc.com`) in Resend; the last direct delivery attempt returned HTTP 403 because the domain was not verified. Verifying the domain or using a verified sender is an external setup step, not a code fix.

## Running locally
Use Node.js 24 and pnpm. Install with `pnpm install`, then run `pnpm --filter @workspace/api-server run dev` and `pnpm --filter @workspace/executive-comp-calculator run dev` in separate terminals. Configure the required environment variables in your hosting environment (do not commit them): `DATABASE_URL`, `RESEND_API_KEY`, `EMAIL_FROM`, `LEAD_NOTIFICATION_EMAIL`, and the appropriate Clerk keys for authentication. Database setup is managed by the workspace packages.
